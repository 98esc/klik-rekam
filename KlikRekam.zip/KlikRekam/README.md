# Klik Rekam 1.1
Rekam tap/tahan/geser, putar ulang otomatis, config tersimpan otomatis (config.json).

Fitur: tombol Stop, Volume Bawah = stop darurat, hitung mundur, jeda antar ulang, batas waktu,
kecepatan, titik sentuh visual, rekam langsung, edit/hapus langkah, salin/impor config,
penjaga orientasi + skala resolusi.

Build: GitHub Actions (lihat panduan) atau Android Studio.
APK ditandatangani dengan app/debug.keystore tetap -> update APK menimpa versi lama tanpa hapus data
(khusus pemasangan pertama dari versi 1.0 harus uninstall dulu karena kunci tanda tangannya beda).
