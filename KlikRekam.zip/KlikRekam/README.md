# Klik Rekam
Auto-clicker dengan rekam jejak sentuh (tap + geser) dan simpan otomatis ke config.json.

Build: buka folder ini di Android Studio (Hedgehog+), Sync, lalu Run. Wrapper Gradle dibuat otomatis oleh Android Studio.
Config: <filesDir>/config.json  ->  {"loop":1,"speed":1.0,"steps":[{"delay":500,"points":[[x,y,t],...]}]}
Simpan otomatis terjadi: setiap goresan selesai direkam, saat Selesai ditekan, dan saat loop/kecepatan diubah.
Catatan: layar penuh saat merekam menangkap sentuhan, jadi aplikasi di belakang tidak ikut bereaksi saat rekam.
