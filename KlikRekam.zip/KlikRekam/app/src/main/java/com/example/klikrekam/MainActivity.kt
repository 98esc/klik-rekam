package com.example.klikrekam

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var loop: EditText
    private lateinit var speed: EditText
    private var loading = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }
        fun add(v: android.view.View) = root.addView(v, ViewGroup.LayoutParams(-1, -2))

        add(TextView(this).apply { text = "Klik Rekam"; textSize = 24f })
        add(TextView(this).apply {
            text = "1. Aktifkan layanan aksesibilitas.\n2. Buka aplikasi target, tekan ● Rekam pada panel melayang, " +
                "lakukan tap/geser, lalu ■ Selesai. Rekaman otomatis tersimpan ke config.\n3. Tekan ▶ Putar."
            setPadding(0, 24, 0, 24)
        })
        add(Button(this).apply {
            text = "Buka pengaturan aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        status = TextView(this).apply { setPadding(0, 24, 0, 24) }; add(status)

        add(TextView(this).apply { text = "Jumlah ulang (0 = tanpa henti)" })
        loop = EditText(this).apply { inputType = 2 }; add(loop)
        add(TextView(this).apply { text = "Kecepatan (1.0 = normal, 2.0 = 2x lebih cepat)" })
        speed = EditText(this).apply { inputType = 8194 }; add(speed)

        val saver = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { if (!loading) saveSettings() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        }
        loop.addTextChangedListener(saver); speed.addTextChangedListener(saver)

        add(Button(this).apply {
            text = "Hapus rekaman"
            setOnClickListener {
                val c = ConfigStore.load(this@MainActivity); c.steps.clear()
                ConfigStore.save(this@MainActivity, c); refresh()
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun saveSettings() {
        val c = ConfigStore.load(this)                       // AUTO-SIMPAN saat nilai diubah
        c.loop = loop.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: c.loop
        c.speed = speed.text.toString().toFloatOrNull()?.coerceIn(0.1f, 10f) ?: c.speed
        ConfigStore.save(this, c)
    }

    private fun refresh() {
        val c = ConfigStore.load(this)
        loading = true
        loop.setText(c.loop.toString()); speed.setText(c.speed.toString())
        loading = false
        val on = ClickService.instance != null
        status.text = (if (on) "Layanan: AKTIF" else "Layanan: belum aktif") +
            "\nConfig tersimpan: ${c.steps.size} langkah\n(${filesDir}/config.json)"
    }
}
