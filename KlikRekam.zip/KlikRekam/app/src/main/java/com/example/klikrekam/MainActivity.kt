package com.example.klikrekam

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private var scroll: ScrollView? = null

    override fun onResume() { super.onResume(); render() }

    private fun isServiceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private fun render() {
        val keep = scroll?.scrollY ?: 0
        val c = ConfigStore.load(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(32))
        }
        root.addView(TextView(this).apply {
            text = "Klik Rekam"; textSize = 26f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Rekam sentuhan, putar ulang otomatis."; setTextColor(MUTED); setPadding(0, dp(2), 0, dp(4))
        })
        statusCard(root)
        recordingCard(root, c)
        settingsCard(root, c)
        backupCard(root)

        val sv = ScrollView(this).apply { setBackgroundColor(BG); addView(root) }
        scroll = sv
        setContentView(sv)
        sv.post { sv.scrollTo(0, keep) }
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Color.WHITE, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            elevation = dp(1).toFloat()
        }
        parent.addView(c, lp(MATCH, WRAP, t = 12))
        c.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })
        return c
    }

    private fun body(t: String) = TextView(this).apply { text = t; setTextColor(MUTED); textSize = 14f }

    // ---------------------------------------------------------------- status
    private fun statusCard(root: LinearLayout) {
        val on = isServiceOn()
        val card = card(root, "Layanan")
        card.addView(TextView(this).apply {
            text = if (on) "● Aktif" else "● Belum aktif"
            setTextColor(if (on) GREEN else RED); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        })
        card.addView(body(
            if (on) "Buka aplikasi tujuan. Panel melayang berisi Rekam, Putar, dan Stop (geser lewat ⠿, kecilkan lewat —).\n" +
                "Darurat: tekan Volume Bawah untuk berhenti kapan saja."
            else "Aktifkan layanan agar Klik Rekam dapat merekam dan menyentuh layar.\n" +
                "Jika diblokir (Android 13+): Info aplikasi → ⋮ → Izinkan setelan terbatas."
        ), lp(MATCH, WRAP, t = 6, b = 8))
        if (!on) card.addView(pill("Buka pengaturan aksesibilitas", BLUE) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
    }

    // ---------------------------------------------------------------- rekaman
    private fun describe(i: Int, s: Step): String {
        val a = s.points.first(); val b = s.points.last()
        val tap = s.points.all { hypot(it.x - a.x, it.y - a.y) <= 20f }
        val what = if (tap) (if (s.durationMs >= 500) "Tahan" else "Tap") + " (${a.x.toInt()}, ${a.y.toInt()})"
        else "Geser (${a.x.toInt()}, ${a.y.toInt()}) → (${b.x.toInt()}, ${b.y.toInt()})"
        return "${i + 1}. $what\n    ${s.durationMs} ms · jeda ${s.delayMs} ms"
    }

    private fun recordingCard(root: LinearLayout, c: Config) {
        val card = card(root, "Rekaman")
        val total = c.steps.sumOf { it.delayMs + it.durationMs }
        card.addView(body(
            if (c.steps.isEmpty()) "Belum ada rekaman. Tekan ● Rekam pada panel melayang."
            else "${c.steps.size} langkah · total ${"%.1f".format(total / 1000.0)} dtk · ketuk baris untuk ubah jeda"
        ), lp(MATCH, WRAP, b = 6))
        c.steps.forEachIndexed { i, s ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply {
                text = describe(i, s); setTextColor(INK); textSize = 13f
                setPadding(0, dp(6), 0, dp(6)); setOnClickListener { editDelay(i, s) }
            }, lp(0, WRAP, weight = 1f))
            row.addView(TextView(this).apply {
                text = "✕"; setTextColor(RED); textSize = 18f; setPadding(dp(12), dp(6), dp(4), dp(6))
                setOnClickListener {
                    ConfigStore.update(this@MainActivity) { cf -> if (i < cf.steps.size) cf.steps.removeAt(i) }
                    render()
                }
            })
            card.addView(row, lp(MATCH, WRAP))
        }
        if (c.steps.isNotEmpty()) card.addView(pill("Hapus semua rekaman", GREY) {
            AlertDialog.Builder(this).setTitle("Hapus semua rekaman?")
                .setPositiveButton("Hapus") { _, _ ->
                    ConfigStore.update(this) { cf -> cf.steps.clear() }; render()
                }.setNegativeButton("Batal", null).show()
        }, lp(WRAP, WRAP, t = 8))
    }

    private fun editDelay(i: Int, s: Step) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(s.delayMs.toString()) }
        AlertDialog.Builder(this).setTitle("Jeda sebelum langkah ${i + 1} (ms)").setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().toLongOrNull()
                if (v != null) {
                    ConfigStore.update(this) { cf ->
                        if (i < cf.steps.size) cf.steps[i] = cf.steps[i].copy(delayMs = v.coerceIn(0L, 600_000L))
                    }
                    render()
                }
            }.setNegativeButton("Batal", null).show()
    }

    // ---------------------------------------------------------------- pengaturan
    private fun stepper(card: LinearLayout, label: String, initial: String, change: (Int) -> String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = label; setTextColor(INK) }, lp(0, WRAP, weight = 1f))
        val value = TextView(this).apply {
            text = initial; gravity = Gravity.CENTER; minWidth = dp(76)
            setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
        }
        row.addView(pill("−", GREY) { value.text = change(-1) }, lp(WRAP, WRAP))
        row.addView(value, lp(WRAP, WRAP, l = 4, r = 4))
        row.addView(pill("+", GREY) { value.text = change(1) }, lp(WRAP, WRAP))
        card.addView(row, lp(MATCH, WRAP, t = 6, b = 6))
    }

    private fun switchRow(card: LinearLayout, label: String, on: Boolean, set: (Boolean) -> Unit) {
        card.addView(Switch(this).apply {
            text = label; isChecked = on; setTextColor(INK)
            setOnCheckedChangeListener { _, b -> set(b) }
        }, lp(MATCH, WRAP, t = 6, b = 6))
    }

    private fun settingsCard(root: LinearLayout, c: Config) {
        val card = card(root, "Pengaturan (tersimpan otomatis)")
        fun loopText(n: Int) = if (n == 0) "∞" else "${n}×"
        fun sec(ms: Long) = "${"%.1f".format(ms / 1000.0)} dtk"

        stepper(card, "Jumlah ulang", loopText(c.loop)) { d ->
            loopText(ConfigStore.update(this) { it.loop = (it.loop + d).coerceIn(0, 9999) }.loop)
        }
        stepper(card, "Kecepatan", "${c.speed}×") { d ->
            "${ConfigStore.update(this) {
                it.speed = (((it.speed + d * 0.25f) * 100).roundToInt() / 100f).coerceIn(0.25f, 4f)
            }.speed}×"
        }
        stepper(card, "Jeda antar ulang", sec(c.loopDelayMs)) { d ->
            sec(ConfigStore.update(this) { it.loopDelayMs = (it.loopDelayMs + d * 100L).coerceIn(0L, 60_000L) }.loopDelayMs)
        }
        stepper(card, "Hitung mundur", "${c.countdownSec} dtk") { d ->
            "${ConfigStore.update(this) { it.countdownSec = (it.countdownSec + d).coerceIn(0, 30) }.countdownSec} dtk"
        }
        stepper(card, "Batas waktu", if (c.timeLimitMin == 0) "Tanpa batas" else "${c.timeLimitMin} mnt") { d ->
            val m = ConfigStore.update(this) { it.timeLimitMin = (it.timeLimitMin + d).coerceIn(0, 600) }.timeLimitMin
            if (m == 0) "Tanpa batas" else "$m mnt"
        }
        switchRow(card, "Tampilkan titik sentuh saat memutar", c.showTouch) { b ->
            ConfigStore.update(this) { it.showTouch = b }
        }
        switchRow(card, "Jalankan sentuhan langsung saat merekam", c.liveRecord) { b ->
            ConfigStore.update(this) { it.liveRecord = b }
        }
        card.addView(body("\"Langsung\" membuat aplikasi di belakang ikut bereaksi saat Anda merekam, sehingga urutan langkah (misal membuka menu) sama persis dengan saat diputar."),
            lp(MATCH, WRAP, t = 4))
    }

    // ---------------------------------------------------------------- cadangan
    private fun backupCard(root: LinearLayout) {
        val card = card(root, "Cadangan config")
        card.addView(body("Config otomatis tersimpan di:\n$filesDir/config.json"), lp(MATCH, WRAP, b = 8))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        row.addView(pill("Salin config", BLUE) {
            cm.setPrimaryClip(ClipData.newPlainText("config", ConfigStore.readRaw(this)))
            Toast.makeText(this, "Config disalin ke clipboard", Toast.LENGTH_SHORT).show()
        }, lp(WRAP, WRAP, r = 8))
        row.addView(pill("Impor dari clipboard", GREY) {
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString()
            try {
                if (t == null) throw IllegalArgumentException()
                ConfigStore.save(this, ConfigStore.parse(t)); render()
                Toast.makeText(this, "Config diimpor", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Isi clipboard bukan config yang valid", Toast.LENGTH_SHORT).show()
            }
        }, lp(WRAP, WRAP))
        card.addView(row)
    }
}
