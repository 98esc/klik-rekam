package com.example.klikrekam

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

class ClickService : AccessibilityService() {

    companion object { @Volatile var instance: ClickService? = null }

    private enum class State { IDLE, RECORDING, COUNTDOWN, PLAYING }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val sched = Handler(Looper.getMainLooper())

    private var cfg = Config()
    private var state = State.IDLE
    private var runId = 0
    private var statusText = ""

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var recBtn: TextView? = null
    private var playBtn: TextView? = null
    private var stopBtn: TextView? = null
    private var miniBtn: TextView? = null
    private var info: TextView? = null
    private var minimized = false

    private var capture: CaptureView? = null
    private var captureLp: WindowManager.LayoutParams? = null
    private var touchView: TouchView? = null
    private var firstStroke = true

    private var deadline = Long.MAX_VALUE
    private var sx = 1f
    private var sy = 1f

    // ------------------------------------------------------------ siklus layanan
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAll(false) }

    override fun onDestroy() {
        stopAll(false)
        removeView(panel); instance = null
        super.onDestroy()
    }

    /** Tombol Volume Bawah = berhenti darurat saat merekam/memutar. */
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && state != State.IDLE) {
            if (e.action == KeyEvent.ACTION_DOWN) stopAll(true)
            return true
        }
        return false
    }

    // ------------------------------------------------------------ rekam
    private fun startRecording() {
        if (state != State.IDLE) return
        cfg = ConfigStore.load(this)
        val (w, h) = screenSize()
        cfg.screenW = w; cfg.screenH = h
        firstStroke = true            // rekaman lama baru diganti setelah goresan pertama
        state = State.RECORDING

        val lp = overlayParams(touchable = true)
        val v = CaptureView(this) { step -> onStrokeRecorded(step) }
        capture = v; captureLp = lp
        wm.addView(v, lp)
        bringPanelToFront()
        refreshUi()
        toast("Merekam: sentuh layar. Tekan Stop jika selesai.")
    }

    private fun onStrokeRecorded(raw: Step) {
        val step = if (firstStroke) raw.copy(delayMs = 0) else raw
        if (firstStroke) { cfg.steps = mutableListOf(); firstStroke = false }
        cfg.steps.add(step)
        commit()                       // AUTO-SIMPAN tiap goresan selesai
        refreshUi()
        if (cfg.liveRecord) dispatchLive(step)
    }

    /** Menjalankan goresan yang baru direkam ke aplikasi di belakang agar kondisi layar tetap sama seperti saat diputar. */
    private fun dispatchLive(s: Step) {
        val v = capture ?: return
        val lp = captureLp ?: return
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) { return }
        val restore = {
            if (state == State.RECORDING && capture === v) {
                lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
        }
        val dur = s.durationMs.coerceIn(cfg.minTapMs.toLong(), 59_000L)
        val ok = dispatchGesture(buildGesture(s, dur, 1f, 1f), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post(restore) }
            override fun onCancelled(g: GestureDescription?) { ui.post(restore) }
        }, null)
        if (!ok) restore()
    }

    private fun stopRecording() {
        state = State.IDLE
        removeView(capture); capture = null; captureLp = null
        if (!firstStroke) commit()
        refreshUi()
        toast(if (firstStroke) "Tidak ada goresan, rekaman lama dipertahankan"
              else "Tersimpan ke config: ${cfg.steps.size} langkah")
    }

    private fun commit() {
        ConfigStore.update(this) { it.steps = cfg.steps; it.screenW = cfg.screenW; it.screenH = cfg.screenH }
    }

    // ------------------------------------------------------------ putar
    private fun startPlayback() {
        if (state != State.IDLE) return
        cfg = ConfigStore.load(this)
        if (cfg.steps.isEmpty()) { toast("Belum ada rekaman. Tekan Rekam dulu."); return }
        val (w, h) = screenSize()
        if (cfg.screenW > 0 && cfg.screenH > 0) {
            if ((cfg.screenW > cfg.screenH) != (w > h)) {
                toast("Orientasi layar berbeda dari saat merekam. Putar layar dulu."); return
            }
            sx = w.toFloat() / cfg.screenW; sy = h.toFloat() / cfg.screenH
        } else { sx = 1f; sy = 1f }
        state = State.COUNTDOWN
        runId++
        countdown(runId, cfg.countdownSec)
    }

    private fun countdown(id: Int, n: Int) {
        if (state != State.COUNTDOWN || id != runId) return
        if (n <= 0) { beginPlay(id); return }
        setStatus("Mulai dalam $n…")
        sched.postDelayed({ countdown(id, n - 1) }, 1000)
    }

    private fun beginPlay(id: Int) {
        state = State.PLAYING
        val now = SystemClock.uptimeMillis()
        deadline = if (cfg.timeLimitMin > 0) now + cfg.timeLimitMin * 60_000L else Long.MAX_VALUE
        if (cfg.showTouch) {
            val t = TouchView(this); touchView = t
            wm.addView(t, overlayParams(touchable = false))
            bringPanelToFront()
        }
        setMinimized(true)            // panel kecil agar tidak menutupi/tersentuh di game
        refreshUi()
        scheduleRound(id, 1, now + 150)
    }

    /**
     * Seluruh langkah satu putaran dijadwalkan sekaligus pada waktu ABSOLUT (uptime), tidak menunggu
     * callback gesture sebelumnya. Hasilnya jeda sama persis dengan rekaman dan tidak melenceng.
     */
    private fun scheduleRound(id: Int, round: Int, t0: Long) {
        if (state != State.PLAYING || id != runId) return
        val sp = cfg.speed.coerceIn(0.1f, 10f)
        var t = t0
        for ((i, s) in cfg.steps.withIndex()) {
            t += (s.delayMs / sp).toLong()
            val startAt = t
            val dur = (s.durationMs / sp).toLong().coerceIn(cfg.minTapMs.toLong(), 59_000L)
            t += dur
            sched.postAtTime({ fire(id, s, i, round, dur) }, startAt)
        }
        if (cfg.loop != 0 && round >= cfg.loop) {
            sched.postAtTime({ if (state == State.PLAYING && id == runId) finish("Selesai") }, t + 300)
        } else {
            val next = t + cfg.loopDelayMs
            sched.postAtTime({ scheduleRound(id, round + 1, next) }, t)
        }
    }

    private fun fire(id: Int, s: Step, index: Int, round: Int, dur: Long) {
        if (state != State.PLAYING || id != runId) return
        if (SystemClock.uptimeMillis() >= deadline) { finish("Batas waktu tercapai"); return }
        setStatus("Memutar · ulang $round${if (cfg.loop > 0) "/${cfg.loop}" else ""} · langkah ${index + 1}/${cfg.steps.size}")
        touchView?.flash(s.points[0].x * sx, s.points[0].y * sy)
        val ok = dispatchGesture(buildGesture(s, dur, sx, sy), null, null)
        if (!ok) finish("Gagal mengirim sentuhan. Cek layanan aksesibilitas.")
    }

    private fun buildGesture(s: Step, dur: Long, sx: Float, sy: Float): GestureDescription {
        val p0 = s.points[0]
        val path = Path().apply {
            moveTo(p0.x * sx, p0.y * sy)
            if (s.points.any { hypot(it.x - p0.x, it.y - p0.y) > 2f })
                for (i in 1 until s.points.size) lineTo(s.points[i].x * sx, s.points[i].y * sy)
        }
        return GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
    }

    private fun finish(msg: String) { stopPlayback(); toast(msg) }

    private fun stopPlayback() {
        state = State.IDLE
        runId++
        sched.removeCallbacksAndMessages(null)
        removeView(touchView); touchView = null
        setMinimized(false)
        refreshUi()
    }

    private fun stopAll(showToast: Boolean) {
        when (state) {
            State.RECORDING -> stopRecording()
            State.IDLE -> {}
            else -> { stopPlayback(); if (showToast) toast("Dihentikan") }
        }
    }

    // ------------------------------------------------------------ panel melayang
    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val drag = TextView(this).apply {
            text = "⠿"; setTextColor(Color.LTGRAY); textSize = 18f
            setPadding(dp(6), dp(6), dp(10), dp(6))
        }
        recBtn = pill("● Rekam", RED) { startRecording() }
        playBtn = pill("▶ Putar", GREEN) { startPlayback() }
        stopBtn = pill("■ Stop", GREY) { stopAll(true) }
        miniBtn = TextView(this).apply {
            text = "—"; setTextColor(Color.LTGRAY); textSize = 16f
            setPadding(dp(10), dp(6), dp(6), dp(6))
            setOnClickListener { toggleMinimize() }
        }
        info = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f; setPadding(dp(6), dp(4), dp(6), 0) }

        row.addView(drag)
        row.addView(recBtn, lp(WRAP, WRAP, r = 6))
        row.addView(playBtn, lp(WRAP, WRAP, r = 6))
        row.addView(stopBtn, lp(WRAP, WRAP))
        row.addView(miniBtn)
        p.addView(row)
        p.addView(info)

        val wlp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; x = 0; y = dp(6) }

        var sxp = 0f; var syp = 0f; var ox = 0; var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sxp = e.rawX; syp = e.rawY; ox = wlp.x; oy = wlp.y }
                MotionEvent.ACTION_MOVE -> {
                    wlp.x = ox + (e.rawX - sxp).toInt(); wlp.y = oy + (e.rawY - syp).toInt()
                    try { wm.updateViewLayout(p, wlp) } catch (_: Exception) {}
                }
            }
            true
        }
        panel = p; panelLp = wlp
        wm.addView(p, wlp)
        refreshUi()
    }

    private fun toggleMinimize() = setMinimized(!minimized)

    private fun setMinimized(m: Boolean) {
        minimized = m
        val vis = if (minimized) View.GONE else View.VISIBLE
        recBtn?.visibility = vis; playBtn?.visibility = vis; info?.visibility = vis
        miniBtn?.text = if (minimized) "▢" else "—"
    }

    private fun bringPanelToFront() {
        val p = panel ?: return
        try { wm.removeView(p) } catch (_: Exception) {}
        wm.addView(p, panelLp)
    }

    private fun setStatus(t: String) { statusText = t; info?.text = t }

    private fun refreshUi() {
        val idle = state == State.IDLE
        fun look(v: TextView?, on: Boolean) { v?.isEnabled = on; v?.alpha = if (on) 1f else 0.35f }
        look(recBtn, idle); look(playBtn, idle); look(stopBtn, !idle)
        stopBtn?.background = roundBg(if (idle) GREY else RED, 20)
        val bg = when (state) {
            State.RECORDING -> 0xF0B71C1C.toInt()
            State.PLAYING, State.COUNTDOWN -> 0xF01B5E20.toInt()
            else -> 0xF0212121.toInt()
        }
        panel?.background = roundBg(bg, 16)
        info?.text = when (state) {
            State.IDLE -> "Siap · ${ConfigStore.load(this).steps.size} langkah · Vol− = stop"
            State.RECORDING -> "Merekam · ${if (firstStroke) 0 else cfg.steps.size} langkah"
            else -> statusText
        }
    }

    // ------------------------------------------------------------ util
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }

    private fun overlayParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = 0
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                fitInsetsTypes = 0
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    private fun removeView(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }
    private fun toast(m: String) = ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    // ------------------------------------------------------------ lapisan rekam
    private class CaptureView(ctx: Context, val onStroke: (Step) -> Unit) : View(ctx) {
        private val paint = Paint().apply {
            color = 0xFFFF5252.toInt(); strokeWidth = 8f; style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND; isAntiAlias = true
        }
        private val trail = Path()           // koordinat LAYAR
        private val loc = IntArray(2)
        private val pts = mutableListOf<Pt>()
        private var downAt = 0L
        private var lastUp = SystemClock.uptimeMillis()
        private var lastX = 0f
        private var lastY = 0f
        private var active = false

        init { setBackgroundColor(0x22000000) }

        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)       // koreksi jika jendela tidak berawal di (0,0) layar
            c.save(); c.translate(-loc[0].toFloat(), -loc[1].toFloat())
            c.drawPath(trail, paint)
            c.restore()
        }

        private fun addPoint(x: Float, y: Float, time: Long) {
            if (hypot(x - lastX, y - lastY) < 6f) return
            pts += Pt(x, y, (time - downAt).coerceAtLeast(0L)); trail.lineTo(x, y)
            lastX = x; lastY = y
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pts.clear(); trail.reset(); active = true
                    downAt = e.eventTime                       // waktu asli kejadian, bukan waktu diproses
                    pts += Pt(e.rawX, e.rawY, 0); trail.moveTo(e.rawX, e.rawY)
                    lastX = e.rawX; lastY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> if (active) {
                    val ox = e.rawX - e.x; val oy = e.rawY - e.y
                    for (h in 0 until e.historySize)           // titik-titik yang terkumpul antar frame
                        addPoint(e.getHistoricalX(h) + ox, e.getHistoricalY(h) + oy, e.getHistoricalEventTime(h))
                    addPoint(e.rawX, e.rawY, e.eventTime)
                }
                MotionEvent.ACTION_UP -> if (active) {
                    active = false
                    val t = (e.eventTime - downAt).coerceAtLeast(1L)
                    val moved = hypot(e.rawX - lastX, e.rawY - lastY) > 0f
                    if (moved || pts.size == 1) pts += Pt(e.rawX, e.rawY, t)
                    else pts[pts.lastIndex] = pts.last().copy(t = t)
                    onStroke(Step((downAt - lastUp).coerceAtLeast(0L), pts.toList()))
                    lastUp = e.eventTime
                }
                MotionEvent.ACTION_CANCEL -> { active = false; trail.reset() }
            }
            invalidate()
            return true
        }
    }

    /** Titik oranye sesaat di lokasi sentuhan saat memutar (koordinat layar, dikoreksi posisi jendela). */
    private class TouchView(ctx: Context) : View(ctx) {
        private val dots = ArrayList<FloatArray>()
        private val loc = IntArray(2)
        private val fill = Paint().apply { color = 0x88FF9800.toInt(); isAntiAlias = true }
        private val ring = Paint().apply {
            color = 0xFFFF6F00.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true
        }
        fun flash(x: Float, y: Float) {
            val d = floatArrayOf(x, y); dots.add(d); invalidate()
            postDelayed({ dots.remove(d); invalidate() }, 400)
        }
        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            val r = 22 * resources.displayMetrics.density
            for (d in dots) {
                val x = d[0] - loc[0]; val y = d[1] - loc[1]
                c.drawCircle(x, y, r, fill); c.drawCircle(x, y, r, ring)
            }
        }
    }
}
