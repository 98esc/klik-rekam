package com.example.klikrekam

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

class ClickService : AccessibilityService() {

    companion object { @Volatile var instance: ClickService? = null }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var cfg = Config()
    private var panel: LinearLayout? = null
    private var capture: CaptureView? = null
    private var recBtn: TextView? = null
    private var playBtn: TextView? = null
    private var info: TextView? = null
    private var recording = false
    private var playing = false
    private var runId = 0

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cfg = ConfigStore.load(this)
        showPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAll() }

    override fun onDestroy() {
        stopAll(); removeView(panel); removeView(capture); instance = null
        super.onDestroy()
    }

    // ---------- Rekam ----------
    private fun startRecording() {
        stopPlayback()
        cfg = ConfigStore.load(this)          // ambil loop/speed terbaru dari config
        cfg.steps = mutableListOf()
        recording = true
        val v = CaptureView(this) { step ->
            cfg.steps.add(step)
            ConfigStore.save(this, cfg)       // AUTO-SIMPAN setiap goresan selesai
            refreshUi()
        }
        capture = v
        wm.addView(v, overlayParams(touchable = true))
        // panel dipasang ulang agar tetap di atas lapisan rekam
        removeView(panel); wm.addView(panel, panelParams())
        refreshUi()
    }

    private fun stopRecording() {
        recording = false
        removeView(capture); capture = null
        ConfigStore.save(this, cfg)
        refreshUi()
        toast("Tersimpan ke config: ${cfg.steps.size} langkah")
    }

    // ---------- Putar ----------
    private fun startPlayback() {
        cfg = ConfigStore.load(this)
        if (cfg.steps.isEmpty()) { toast("Belum ada rekaman"); return }
        playing = true; runId++
        refreshUi()
        playStep(runId, 0, 0)
    }

    private fun stopPlayback() { playing = false; runId++; refreshUi() }

    private fun playStep(id: Int, index: Int, round: Int) {
        if (!playing || id != runId) return
        if (index >= cfg.steps.size) {
            val next = round + 1
            if (cfg.loop != 0 && next >= cfg.loop) { stopPlayback(); return }
            playStep(id, 0, next); return
        }
        val s = cfg.steps[index]
        val sp = cfg.speed.coerceIn(0.1f, 10f)
        ui.postDelayed({
            if (!playing || id != runId) return@postDelayed
            val path = Path().apply {
                moveTo(s.points[0].x, s.points[0].y)
                for (i in 1 until s.points.size) lineTo(s.points[i].x, s.points[i].y)
            }
            val dur = (s.durationMs / sp).toLong().coerceIn(1L, 59_000L)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { playStep(id, index + 1, round) }
                override fun onCancelled(d: GestureDescription?) { playStep(id, index + 1, round) }
            }, null)
            if (!ok) playStep(id, index + 1, round)
        }, (s.delayMs / sp).toLong())
    }

    private fun stopAll() { if (recording) stopRecording(); stopPlayback() }

    // ---------- Panel melayang ----------
    private fun showPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xE6222222.toInt())
            setPadding(8, 8, 8, 8)
        }
        fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 14f
            setPadding(24, 16, 24, 16); setOnClickListener { onClick() }
            p.addView(this)
        }
        val drag = TextView(this).apply { text = "⋮"; setTextColor(Color.LTGRAY); setPadding(16, 16, 16, 16) }
        p.addView(drag)
        recBtn = btn("● Rekam") { if (recording) stopRecording() else startRecording() }
        playBtn = btn("▶ Putar") { if (playing) stopPlayback() else if (!recording) startPlayback() }
        info = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(16, 16, 16, 16); p.addView(this) }

        val lp = panelParams()
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(p, lp)
                }
            }
            true
        }
        panel = p
        wm.addView(p, lp)
        refreshUi()
    }

    private fun refreshUi() {
        ui.post {
            recBtn?.text = if (recording) "■ Selesai" else "● Rekam"
            playBtn?.text = if (playing) "■ Stop" else "▶ Putar"
            info?.text = "${cfg.steps.size} langkah"
        }
    }

    private fun panelParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 200 }

    private fun overlayParams(touchable: Boolean) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun removeView(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }
    private fun toast(m: String) = ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    /** Lapisan layar penuh yang menangkap jejak sentuh dan menggambarnya sebagai garis. */
    private class CaptureView(ctx: Context, val onStroke: (Step) -> Unit) : View(ctx) {
        private val paint = Paint().apply {
            color = 0xFFFF5252.toInt(); strokeWidth = 8f; style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND; isAntiAlias = true
        }
        private val trail = Path()
        private val pts = mutableListOf<Pt>()
        private var downAt = 0L
        private var lastUp = SystemClock.uptimeMillis() - 500   // jeda awal 500 ms
        private var lastX = 0f; private var lastY = 0f

        init { setBackgroundColor(0x22000000) }

        override fun onDraw(c: Canvas) { c.drawPath(trail, paint) }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val now = SystemClock.uptimeMillis()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pts.clear(); trail.reset(); downAt = now
                    pts += Pt(e.rawX, e.rawY, 0); trail.moveTo(e.rawX, e.rawY)
                    lastX = e.rawX; lastY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    // sampel titik sepanjang jejak (abaikan gerakan < 8 px)
                    if (hypot(e.rawX - lastX, e.rawY - lastY) >= 8f) {
                        pts += Pt(e.rawX, e.rawY, now - downAt); trail.lineTo(e.rawX, e.rawY)
                        lastX = e.rawX; lastY = e.rawY
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val t = (now - downAt).coerceAtLeast(1)
                    if (pts.size == 1 || hypot(e.rawX - lastX, e.rawY - lastY) > 0f)
                        pts += Pt(e.rawX, e.rawY, t)
                    else pts[pts.size - 1] = pts.last().copy(t = t)
                    onStroke(Step(downAt - lastUp, pts.toList()))
                    lastUp = now
                }
            }
            invalidate()
            return true
        }
    }
}
