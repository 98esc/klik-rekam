package com.example.klikrekam

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.hypot

class ClickService : AccessibilityService() {

    companion object { @Volatile var instance: ClickService? = null }

    private enum class State { IDLE, RECORDING, COUNTDOWN, PLAYING }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val sched = Handler(Looper.getMainLooper())

    private var cfg = Config()
    private var state = State.IDLE
    private var runId = 0
    private var statusText = ""

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var recBtn: TextView? = null
    private var playBtn: TextView? = null
    private var stopBtn: TextView? = null
    private var viewBtn: TextView? = null
    private var miniBtn: TextView? = null
    private var info: TextView? = null
    private var minimized = false

    private var capture: CaptureView? = null
    private var captureLp: WindowManager.LayoutParams? = null
    private var touchView: TouchView? = null
    private var firstStroke = true

    private var deadline = Long.MAX_VALUE
    private var sx = 1f
    private var sy = 1f

    // ------------------------------------------------------------ siklus layanan
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAll(false) }

    override fun onDestroy() {
        stopAll(false)
        removeView(panel); instance = null
        super.onDestroy()
    }

    /** Tombol Volume Bawah = berhenti darurat saat merekam/memutar. */
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && state != State.IDLE) {
            if (e.action == KeyEvent.ACTION_DOWN) stopAll(true)
            return true
        }
        return false
    }

    // ------------------------------------------------------------ rekam
    private fun startRecording() {
        if (state != State.IDLE) return
        clearPreview()
        cfg = ConfigStore.load(this)
        val (w, h) = screenSize()
        cfg.screenW = w; cfg.screenH = h
        firstStroke = true            // rekaman lama baru diganti setelah goresan pertama
        state = State.RECORDING

        val lp = overlayParams(touchable = true)
        val v = CaptureView(this) { step -> onStrokeRecorded(step) }
        capture = v; captureLp = lp
        wm.addView(v, lp)
        bringPanelToFront()
        refreshUi()
        toast("Merekam: sentuh layar. Tekan Stop jika selesai.")
    }

    private fun onStrokeRecorded(raw: Step) {
        val n = normalize(raw)
        val step = if (firstStroke) n.copy(delayMs = 0) else n
        if (firstStroke) { cfg.steps = mutableListOf(); firstStroke = false }
        cfg.steps.add(step)
        commit()                       // AUTO-SIMPAN tiap goresan selesai
        refreshUi()
        if (cfg.liveRecord) dispatchLive(step)
    }

    /** Menjalankan goresan yang baru direkam ke aplikasi di belakang agar kondisi layar tetap sama seperti saat diputar. */
    private fun dispatchLive(s: Step) {
        val v = capture ?: return
        val lp = captureLp ?: return
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) { return }
        val restore = {
            if (state == State.RECORDING && capture === v) {
                lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
        }
        val dur = s.durationMs.coerceIn(cfg.minTapMs.toLong(), 59_000L)
        val ok = dispatchGesture(buildGesture(s, dur, 1f, 1f), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post(restore) }
            override fun onCancelled(g: GestureDescription?) { ui.post(restore) }
        }, null)
        if (!ok) restore()
        // DOWN gesture sudah terkirim dalam beberapa puluh ms; sisa gesture tetap milik game, jadi
        // lapisan rekam boleh segera menerima sentuhan berikutnya (tap beruntun tidak hilang).
        ui.postDelayed(restore, minOf(dur, 70L) + 40L)
    }

    private fun stopRecording() {
        state = State.IDLE
        removeView(capture); capture = null; captureLp = null
        if (!firstStroke) commit()
        refreshUi()
        toast(if (firstStroke) "Tidak ada goresan, rekaman lama dipertahankan"
              else "Tersimpan ke config: ${cfg.steps.size} langkah")
    }

    private fun commit() {
        ConfigStore.update(this) { it.steps = cfg.steps; it.screenW = cfg.screenW; it.screenH = cfg.screenH }
    }

    // ------------------------------------------------------------ putar
    private fun startPlayback() {
        if (state != State.IDLE) return
        cfg = ConfigStore.load(this)
        if (cfg.steps.isEmpty()) { toast("Belum ada rekaman. Tekan Rekam dulu."); return }
        clearPreview()
        if (!prepareScale(cfg)) return
        state = State.COUNTDOWN
        runId++
        countdown(runId, cfg.countdownSec)
    }

    /** Skala koordinat hanya dipakai bila resolusi berubah >12% (selisih kecil = beda bilah navigasi, bukan resolusi). */
    private fun prepareScale(c: Config): Boolean {
        val (w, h) = screenSize()
        sx = 1f; sy = 1f
        if (c.screenW > 0 && c.screenH > 0) {
            if ((c.screenW > c.screenH) != (w > h)) {
                toast("Orientasi layar berbeda dari saat merekam. Putar layar dulu."); return false
            }
            val rx = w.toFloat() / c.screenW; val ry = h.toFloat() / c.screenH
            if (abs(rx - 1f) > 0.12f || abs(ry - 1f) > 0.12f) { sx = rx; sy = ry }
        }
        return true
    }

    private fun countdown(id: Int, n: Int) {
        if (state != State.COUNTDOWN || id != runId) return
        if (n <= 0) { beginPlay(id); return }
        setStatus("Mulai dalam $n…")
        sched.postDelayed({ countdown(id, n - 1) }, 1000)
    }

    private fun beginPlay(id: Int) {
        state = State.PLAYING
        val now = SystemClock.uptimeMillis()
        deadline = if (cfg.timeLimitMin > 0) now + cfg.timeLimitMin * 60_000L else Long.MAX_VALUE
        if (cfg.showTouch) {
            val t = TouchView(this); touchView = t
            wm.addView(t, overlayParams(touchable = false))
            bringPanelToFront()
        }
        setMinimized(true)            // panel kecil agar tidak menutupi/tersentuh di game
        refreshUi()
        scheduleRound(id, 1, now + 150)
    }

    /**
     * Seluruh langkah satu putaran dijadwalkan sekaligus pada waktu ABSOLUT (uptime), tidak menunggu
     * callback gesture sebelumnya. Hasilnya jeda sama persis dengan rekaman dan tidak melenceng.
     */
    private fun scheduleRound(id: Int, round: Int, t0: Long) {
        if (state != State.PLAYING || id != runId) return
        val sp = cfg.speed.coerceIn(0.1f, 10f)
        var t = t0
        for ((i, s) in cfg.steps.withIndex()) {
            t += (s.delayMs / sp).toLong()
            val startAt = t
            val dur = (s.durationMs / sp).toLong().coerceIn(cfg.minTapMs.toLong(), 59_000L)
            t += dur
            sched.postAtTime({ fire(id, s, i, round, dur) }, startAt)
        }
        if (cfg.loop != 0 && round >= cfg.loop) {
            sched.postAtTime({ if (state == State.PLAYING && id == runId) finish("Selesai") }, t + 300)
        } else {
            val next = t + cfg.loopDelayMs
            sched.postAtTime({ scheduleRound(id, round + 1, next) }, t)
        }
    }

    private fun fire(id: Int, s: Step, index: Int, round: Int, dur: Long) {
        if (state != State.PLAYING || id != runId) return
        if (SystemClock.uptimeMillis() >= deadline) { finish("Batas waktu tercapai"); return }
        setStatus("Memutar · ulang $round${if (cfg.loop > 0) "/${cfg.loop}" else ""} · langkah ${index + 1}/${cfg.steps.size}")
        val x0 = s.points[0].x * sx; val y0 = s.points[0].y * sy
        val x1 = s.points.last().x * sx; val y1 = s.points.last().y * sy
        touchView?.flash(x0, y0)
        if (panelHit(x0, y0) || panelHit(x1, y1)) {          // titik di bawah panel: loloskan sentuhan
            setPanelTouchable(false)
            ui.postDelayed({ setPanelTouchable(true) }, dur + 250)
        }
        val ok = dispatchGesture(buildGesture(s, dur, sx, sy), null, null)
        if (!ok) finish("Gagal mengirim sentuhan. Cek layanan aksesibilitas.")
    }

    /**
     * Jari manusia selalu bergeser beberapa piksel saat mengetuk. Jika dikirim apa adanya, game melihatnya
     * sebagai geseran kecil (drag), bukan tap, sehingga tap meleset/tidak terbaca. Gerakan dalam batas
     * touch-slop dijadikan tap TEPAT di titik sentuh pertama.
     */
    private fun normalize(s: Step): Step {
        val p0 = s.points[0]
        val slop = ViewConfiguration.get(this).scaledTouchSlop * 1.5f
        return if (s.points.size > 1 && s.points.all { hypot(it.x - p0.x, it.y - p0.y) <= slop })
            Step(s.delayMs, listOf(Pt(p0.x, p0.y, s.durationMs)))
        else s
    }

    private fun buildGesture(raw: Step, dur: Long, sx: Float, sy: Float): GestureDescription {
        val s = normalize(raw)            // juga memperbaiki rekaman lama
        val p0 = s.points[0]
        val path = Path().apply {
            moveTo(p0.x * sx, p0.y * sy)
            for (i in 1 until s.points.size) lineTo(s.points[i].x * sx, s.points[i].y * sy)
        }
        return GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
    }

    private fun finish(msg: String) { stopPlayback(); toast(msg) }

    private fun stopPlayback() {
        state = State.IDLE
        runId++
        sched.removeCallbacksAndMessages(null)
        removeView(touchView); touchView = null
        setMinimized(false)
        setPanelTouchable(true)
        refreshUi()
    }

    private fun stopAll(showToast: Boolean) {
        when (state) {
            State.RECORDING -> stopRecording()
            State.IDLE -> {}
            else -> { stopPlayback(); if (showToast) toast("Dihentikan") }
        }
    }

    // ------------------------------------------------------------ panel melayang
    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val drag = TextView(this).apply {
            text = "⠿"; setTextColor(Color.LTGRAY); textSize = 18f
            setPadding(dp(6), dp(6), dp(10), dp(6))
        }
        recBtn = pill("● Rekam", RED) { startRecording() }
        playBtn = pill("▶ Putar", GREEN) { startPlayback() }
        stopBtn = pill("■ Stop", GREY) { stopAll(true) }
        viewBtn = pill("◎", BLUE) { showPreview() }
        miniBtn = TextView(this).apply {
            text = "—"; setTextColor(Color.LTGRAY); textSize = 16f
            setPadding(dp(10), dp(6), dp(6), dp(6))
            setOnClickListener { toggleMinimize() }
        }
        info = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f; setPadding(dp(6), dp(4), dp(6), 0) }

        row.addView(drag)
        row.addView(recBtn, lp(WRAP, WRAP, r = 6))
        row.addView(playBtn, lp(WRAP, WRAP, r = 6))
        row.addView(stopBtn, lp(WRAP, WRAP, r = 6))
        row.addView(viewBtn, lp(WRAP, WRAP))
        row.addView(miniBtn)
        p.addView(row)
        p.addView(info)

        val wlp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; x = 0; y = dp(6) }

        var sxp = 0f; var syp = 0f; var ox = 0; var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sxp = e.rawX; syp = e.rawY; ox = wlp.x; oy = wlp.y }
                MotionEvent.ACTION_MOVE -> {
                    wlp.x = ox + (e.rawX - sxp).toInt(); wlp.y = oy + (e.rawY - syp).toInt()
                    try { wm.updateViewLayout(p, wlp) } catch (_: Exception) {}
                }
            }
            true
        }
        panel = p; panelLp = wlp
        wm.addView(p, wlp)
        refreshUi()
    }

    private fun panelHit(x: Float, y: Float): Boolean {
        val p = panel ?: return false
        val l = IntArray(2); p.getLocationOnScreen(l)
        val m = dp(12)
        return x >= l[0] - m && x <= l[0] + p.width + m && y >= l[1] - m && y <= l[1] + p.height + m
    }

    private fun setPanelTouchable(on: Boolean) {
        val p = panel ?: return; val lp = panelLp ?: return
        val f = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        lp.flags = if (on) lp.flags and f.inv() else lp.flags or f
        try { wm.updateViewLayout(p, lp) } catch (_: Exception) {}
    }

    private var preview: TouchView? = null
    private fun clearPreview() { removeView(preview); preview = null }

    /** Menampilkan nomor + posisi tiap langkah di atas layar selama 6 detik, untuk mengecek ketepatan titik. */
    private fun showPreview() {
        if (state != State.IDLE) return
        clearPreview()
        val c = ConfigStore.load(this)
        if (c.steps.isEmpty()) { toast("Belum ada rekaman"); return }
        if (!prepareScale(c)) return
        val t = TouchView(this); preview = t
        wm.addView(t, overlayParams(touchable = false))
        bringPanelToFront()
        t.setMarks(c.steps.map {
            val n = normalize(it); val a = n.points.first(); val b = n.points.last()
            floatArrayOf(a.x * sx, a.y * sy, b.x * sx, b.y * sy)
        })
        ui.postDelayed({ if (preview === t) clearPreview() }, 6000)
    }

    private fun toggleMinimize() = setMinimized(!minimized)

    private fun setMinimized(m: Boolean) {
        minimized = m
        val vis = if (minimized) View.GONE else View.VISIBLE
        recBtn?.visibility = vis; playBtn?.visibility = vis; viewBtn?.visibility = vis; info?.visibility = vis
        miniBtn?.text = if (minimized) "▢" else "—"
    }

    private fun bringPanelToFront() {
        val p = panel ?: return
        try { wm.removeView(p) } catch (_: Exception) {}
        wm.addView(p, panelLp)
    }

    private fun setStatus(t: String) { statusText = t; info?.text = t }

    private fun refreshUi() {
        val idle = state == State.IDLE
        fun look(v: TextView?, on: Boolean) { v?.isEnabled = on; v?.alpha = if (on) 1f else 0.35f }
        look(recBtn, idle); look(playBtn, idle); look(viewBtn, idle); look(stopBtn, !idle)
        stopBtn?.background = roundBg(if (idle) GREY else RED, 20)
        val bg = when (state) {
            State.RECORDING -> 0xF0B71C1C.toInt()
            State.PLAYING, State.COUNTDOWN -> 0xF01B5E20.toInt()
            else -> 0xF0212121.toInt()
        }
        panel?.background = roundBg(bg, 16)
        info?.text = when (state) {
            State.IDLE -> "Siap · ${ConfigStore.load(this).steps.size} langkah · Vol− = stop"
            State.RECORDING -> "Merekam · ${if (firstStroke) 0 else cfg.steps.size} langkah"
            else -> statusText
        }
    }

    // ------------------------------------------------------------ util
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }

    private fun overlayParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = 0
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                fitInsetsTypes = 0
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    private fun removeView(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }
    private fun toast(m: String) = ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    // ------------------------------------------------------------ lapisan rekam
    private class CaptureView(ctx: Context, val onStroke: (Step) -> Unit) : View(ctx) {
        private val paint = Paint().apply {
            color = 0xFFFF5252.toInt(); strokeWidth = 8f; style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND; isAntiAlias = true
        }
        private val trail = Path()           // koordinat LAYAR
        private val loc = IntArray(2)
        private val pts = mutableListOf<Pt>()
        private var downAt = 0L
        private var lastUp = SystemClock.uptimeMillis()
        private var lastX = 0f
        private var lastY = 0f
        private var active = false

        init { setBackgroundColor(0x22000000) }

        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)       // koreksi jika jendela tidak berawal di (0,0) layar
            c.save(); c.translate(-loc[0].toFloat(), -loc[1].toFloat())
            c.drawPath(trail, paint)
            c.restore()
        }

        private fun addPoint(x: Float, y: Float, time: Long) {
            if (hypot(x - lastX, y - lastY) < 6f) return
            pts += Pt(x, y, (time - downAt).coerceAtLeast(0L)); trail.lineTo(x, y)
            lastX = x; lastY = y
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pts.clear(); trail.reset(); active = true
                    downAt = e.eventTime                       // waktu asli kejadian, bukan waktu diproses
                    pts += Pt(e.rawX, e.rawY, 0); trail.moveTo(e.rawX, e.rawY)
                    lastX = e.rawX; lastY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> if (active) {
                    val ox = e.rawX - e.x; val oy = e.rawY - e.y
                    for (h in 0 until e.historySize)           // titik-titik yang terkumpul antar frame
                        addPoint(e.getHistoricalX(h) + ox, e.getHistoricalY(h) + oy, e.getHistoricalEventTime(h))
                    addPoint(e.rawX, e.rawY, e.eventTime)
                }
                MotionEvent.ACTION_UP -> if (active) {
                    active = false
                    val t = (e.eventTime - downAt).coerceAtLeast(1L)
                    val moved = hypot(e.rawX - lastX, e.rawY - lastY) > 0f
                    if (moved || pts.size == 1) pts += Pt(e.rawX, e.rawY, t)
                    else pts[pts.lastIndex] = pts.last().copy(t = t)
                    onStroke(Step((downAt - lastUp).coerceAtLeast(0L), pts.toList()))
                    lastUp = e.eventTime
                }
                MotionEvent.ACTION_CANCEL -> { active = false; trail.reset() }
            }
            invalidate()
            return true
        }
    }

    /** Titik oranye sesaat saat memutar + pratinjau bernomor (koordinat layar, dikoreksi posisi jendela). */
    private class TouchView(ctx: Context) : View(ctx) {
        private val dots = ArrayList<FloatArray>()
        private var marks: List<FloatArray> = emptyList()
        private val loc = IntArray(2)
        private val d = resources.displayMetrics.density
        private val fill = Paint().apply { color = 0x88FF9800.toInt(); isAntiAlias = true }
        private val ring = Paint().apply {
            color = 0xFFFF6F00.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true
        }
        private val badge = Paint().apply { color = 0xDD1565C0.toInt(); isAntiAlias = true }
        private val line = Paint().apply {
            color = 0xCCFF6F00.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true
        }
        private val txt = Paint().apply {
            color = Color.WHITE; textSize = 13 * d; textAlign = Paint.Align.CENTER
            isFakeBoldText = true; isAntiAlias = true
        }

        fun flash(x: Float, y: Float) {
            val p = floatArrayOf(x, y); dots.add(p); invalidate()
            postDelayed({ dots.remove(p); invalidate() }, 400)
        }

        fun setMarks(m: List<FloatArray>) { marks = m; invalidate() }

        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            c.save(); c.translate(-loc[0].toFloat(), -loc[1].toFloat())
            val r = 22 * d
            for ((i, m) in marks.withIndex()) {
                if (hypot(m[2] - m[0], m[3] - m[1]) > 2f) c.drawLine(m[0], m[1], m[2], m[3], line)
                c.drawCircle(m[0], m[1], r, fill); c.drawCircle(m[0], m[1], r, ring)
                c.drawCircle(m[0], m[1], 11 * d, badge)
                c.drawText("${i + 1}", m[0], m[1] + txt.textSize * 0.35f, txt)
            }
            for (p in dots) { c.drawCircle(p[0], p[1], r, fill); c.drawCircle(p[0], p[1], r, ring) }
            c.restore()
        }
    }
}
