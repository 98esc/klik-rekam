package com.example.klikrekam

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

val BG = 0xFFF3F5F9.toInt()
val INK = 0xFF1B1F24.toInt()
val MUTED = 0xFF5F6B7A.toInt()
val BLUE = 0xFF1565C0.toInt()
val RED = 0xFFD32F2F.toInt()
val GREEN = 0xFF2E7D32.toInt()
val GREY = 0xFF546E7A.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.roundBg(color: Int, radiusDp: Int = 12) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(radiusDp).toFloat()
}

fun Context.lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

fun Context.pill(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
    text = label; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
    setPadding(dp(14), dp(10), dp(14), dp(10)); background = roundBg(color, 20)
    isClickable = true; setOnClickListener { onClick() }
}
