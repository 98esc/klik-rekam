package com.example.klikrekam

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Satu titik jejak sentuh; t = ms sejak jari menyentuh layar. */
data class Pt(val x: Float, val y: Float, val t: Long)

/** Satu goresan (tap/tahan/geser). delayMs = jeda sejak goresan sebelumnya selesai. */
data class Step(val delayMs: Long, val points: List<Pt>) {
    val durationMs: Long get() = points.last().t
}

data class Config(
    var loop: Int = 1,               // 0 = tanpa henti
    var speed: Float = 1f,           // 2.0 = dua kali lebih cepat
    var loopDelayMs: Long = 500,     // jeda antar putaran
    var countdownSec: Int = 3,       // hitung mundur sebelum memutar
    var timeLimitMin: Int = 0,       // 0 = tanpa batas waktu
    var showTouch: Boolean = true,   // titik oranye di lokasi sentuhan saat memutar
    var liveRecord: Boolean = true,  // sentuhan langsung dijalankan ke aplikasi saat merekam
    var screenW: Int = 0,
    var screenH: Int = 0,
    var steps: MutableList<Step> = mutableListOf()
)

/** Config disimpan di filesDir/config.json, ditulis atomik. */
object ConfigStore {
    private const val FILE = "config.json"

    fun parse(text: String): Config {
        val o = JSONObject(text)
        val steps = mutableListOf<Step>()
        val arr = o.optJSONArray("steps") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            val pts = s.getJSONArray("points")
            val list = (0 until pts.length()).map {
                val p = pts.getJSONArray(it)
                Pt(p.getDouble(0).toFloat(), p.getDouble(1).toFloat(), p.getLong(2))
            }
            if (list.isNotEmpty()) steps += Step(s.getLong("delay"), list)
        }
        val d = Config()
        return Config(
            loop = o.optInt("loop", d.loop),
            speed = o.optDouble("speed", d.speed.toDouble()).toFloat(),
            loopDelayMs = o.optLong("loopDelayMs", d.loopDelayMs),
            countdownSec = o.optInt("countdownSec", d.countdownSec),
            timeLimitMin = o.optInt("timeLimitMin", d.timeLimitMin),
            showTouch = o.optBoolean("showTouch", d.showTouch),
            liveRecord = o.optBoolean("liveRecord", d.liveRecord),
            screenW = o.optInt("screenW", 0),
            screenH = o.optInt("screenH", 0),
            steps = steps
        )
    }

    fun toJson(c: Config): String {
        val steps = JSONArray()
        c.steps.forEach { s ->
            val pts = JSONArray()
            s.points.forEach { pts.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble()).put(it.t)) }
            steps.put(JSONObject().put("delay", s.delayMs).put("points", pts))
        }
        return JSONObject()
            .put("loop", c.loop).put("speed", c.speed.toDouble())
            .put("loopDelayMs", c.loopDelayMs).put("countdownSec", c.countdownSec)
            .put("timeLimitMin", c.timeLimitMin).put("showTouch", c.showTouch)
            .put("liveRecord", c.liveRecord)
            .put("screenW", c.screenW).put("screenH", c.screenH)
            .put("steps", steps).toString(2)
    }

    @Synchronized
    fun load(ctx: Context): Config {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return Config()
        return try { parse(f.readText()) } catch (e: Exception) { Config() }
    }

    @Synchronized
    fun readRaw(ctx: Context): String = toJson(load(ctx))

    @Synchronized
    fun save(ctx: Context, c: Config) {
        val json = toJson(c)
        val tmp = File(ctx.filesDir, "$FILE.tmp")
        tmp.writeText(json)
        if (!tmp.renameTo(File(ctx.filesDir, FILE))) {
            File(ctx.filesDir, FILE).writeText(json); tmp.delete()
        }
    }

    /** Muat, ubah, simpan otomatis. */
    @Synchronized
    fun update(ctx: Context, block: (Config) -> Unit): Config {
        val c = load(ctx); block(c); save(ctx, c); return c
    }
}
