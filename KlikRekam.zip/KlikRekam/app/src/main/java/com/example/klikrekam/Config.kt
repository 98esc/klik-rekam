package com.example.klikrekam

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Satu titik jejak sentuh; t = ms sejak jari menyentuh layar. */
data class Pt(val x: Float, val y: Float, val t: Long)

/** Satu goresan (tap/geser). delayMs = jeda sejak goresan sebelumnya selesai. */
data class Step(val delayMs: Long, val points: List<Pt>) {
    val durationMs: Long get() = points.last().t
}

data class Config(
    var loop: Int = 1,          // 0 = tanpa henti
    var speed: Float = 1f,      // 2.0 = dua kali lebih cepat
    var steps: MutableList<Step> = mutableListOf()
)

/** Config disimpan di filesDir/config.json, ditulis atomik supaya tidak rusak jika proses mati. */
object ConfigStore {
    private const val FILE = "config.json"

    @Synchronized
    fun load(ctx: Context): Config {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return Config()
        return try {
            val o = JSONObject(f.readText())
            val steps = mutableListOf<Step>()
            val arr = o.optJSONArray("steps") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                val pts = s.getJSONArray("points")
                val list = (0 until pts.length()).map {
                    val p = pts.getJSONArray(it)
                    Pt(p.getDouble(0).toFloat(), p.getDouble(1).toFloat(), p.getLong(2))
                }
                if (list.isNotEmpty()) steps += Step(s.getLong("delay"), list)
            }
            Config(o.optInt("loop", 1), o.optDouble("speed", 1.0).toFloat(), steps)
        } catch (e: Exception) {
            Config() // file rusak -> mulai dari kosong
        }
    }

    @Synchronized
    fun save(ctx: Context, c: Config) {
        val steps = JSONArray()
        c.steps.forEach { s ->
            val pts = JSONArray()
            s.points.forEach { pts.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble()).put(it.t)) }
            steps.put(JSONObject().put("delay", s.delayMs).put("points", pts))
        }
        val json = JSONObject().put("loop", c.loop).put("speed", c.speed.toDouble()).put("steps", steps)
        val tmp = File(ctx.filesDir, "$FILE.tmp")
        tmp.writeText(json.toString())
        if (!tmp.renameTo(File(ctx.filesDir, FILE))) {
            File(ctx.filesDir, FILE).writeText(json.toString()); tmp.delete()
        }
    }
}
